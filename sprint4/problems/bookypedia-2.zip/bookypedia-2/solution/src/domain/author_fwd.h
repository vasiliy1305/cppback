#pragma once

namespace domain {

class Author;

class Book;

class AuthorRepository;

// class BookRepository;

}  // namespace domain