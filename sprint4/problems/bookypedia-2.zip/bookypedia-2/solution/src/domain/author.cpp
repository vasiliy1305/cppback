#include "author.h"
#include <boost/uuid/uuid.hpp>
#include <boost/uuid/random_generator.hpp>

namespace domain {

}  // namespace domain
